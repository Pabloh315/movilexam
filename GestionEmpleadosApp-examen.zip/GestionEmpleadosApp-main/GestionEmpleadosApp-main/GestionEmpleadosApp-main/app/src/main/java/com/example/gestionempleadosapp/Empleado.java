package com.example.gestionempleadosapp;

public abstract class Empleado {
    protected String nombre;
    protected String id;
    protected String departamento;
    protected double salarioBase;
    protected int aniosExperiencia;
    protected int number; // NUEVO atributo

    public Empleado(String nombre, String id, String departamento, double salarioBase, int aniosExperiencia, int number) {
        this.nombre = nombre;
        this.id = id;
        this.departamento = departamento;
        this.salarioBase = salarioBase;
        this.aniosExperiencia = aniosExperiencia;
        this.number = number;
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public String getId() {
        return id;
    }

    public String getDepartamento() {
        return departamento;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public int getAniosExperiencia() {
        return aniosExperiencia;
    }

    public int getNumber() {
        return number;
    }

    public String getNombreCompleto() {
        return nombre;
    }

    // NUEVO: para identificar el tipo de empleado
    public String getTipo() {
        return this.getClass().getSimpleName(); // Retorna "EmpleadoTiempoCompleto", etc.
    }

    public abstract double calcularSalario();

    public abstract String obtenerInformacion();
}
