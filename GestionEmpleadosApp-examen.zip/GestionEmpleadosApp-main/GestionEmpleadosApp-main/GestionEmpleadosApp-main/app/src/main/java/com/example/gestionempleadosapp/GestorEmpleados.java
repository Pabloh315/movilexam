package com.example.gestionempleadosapp;

import java.util.ArrayList;

public class GestorEmpleados {
    private static ArrayList<Empleado> empleados = new ArrayList<>();
    
    // Inicializar con algunos empleados de ejemplo
    static {
//        empleados.add(new EmpleadoTiempoCompleto("Ana Morales", "001", "Admin", 1000, 5, 10, 1));
//        empleados.add(new EmpleadoTiempoCompleto("Pablo Rocabado", "002", "RH", 1100, 4, 12, 1));
//        empleados.add(new EmpleadoTiempoCompleto("Marco Pérez", "003", "Finanzas", 1200, 6, 15, 1));
//        empleados.add(new EmpleadoTiempoCompleto("Laura Díaz", "004", "Marketing", 1300, 3, 9, 1));

        empleados.add(new EmpleadoMedioTiempo("Luis Pérez", "005", "Diseño", 0, 4, 17, 20, 1));
        empleados.add(new EmpleadoMedioTiempo("Kevin Soto", "006", "Soporte", 0, 3, 20, 15, 1));
        empleados.add(new EmpleadoMedioTiempo("Gabriela Rojas", "007", "Ventas", 0, 2, 10, 30, 1));

        empleados.add(new Contratista("Carlos Ruiz", "008", "Logística", 0, 2, 5, 6, 1));
        empleados.add(new Contratista("Daniel Vera", "009", "Proyectos", 0, 1, 6, 3, 1));
        empleados.add(new Contratista("Andrés Gómez", "010", "Sistemas", 0, 4, 8, 2, 1));
    }

    public static ArrayList<Empleado> getEmpleados() {
        return empleados;
    }

    public static void agregarEmpleado(Empleado empleado) {
        empleados.add(empleado);
    }

    public static void limpiarLista() {
        empleados.clear();
    }
} 