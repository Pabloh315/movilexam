package com.example.gestionempleadosapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class InicioActivity extends AppCompatActivity {

    private Button btnVerEmpleados;
    private Button btnResumen;
    private Button btnNuevoEmpleado;
    private Button btnBuscarExperiencia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        btnVerEmpleados = findViewById(R.id.btnVerEmpleados);
        btnResumen = findViewById(R.id.btnResumen);
        btnNuevoEmpleado = findViewById(R.id.btnNuevoEmpleado);
        btnBuscarExperiencia = findViewById(R.id.btnBuscarExperiencia);

        // Botón para ver empleados registrados
        btnVerEmpleados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InicioActivity.this, ListaActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in, android.R.anim.fade_out);
                finish();
            }
        });

        // Botón para ver resumen de empleados por tipo
        btnResumen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InicioActivity.this, ResumenActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in, android.R.anim.fade_out);
            }
        });

        // Botón para agregar nuevo empleado
        btnNuevoEmpleado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InicioActivity.this, NuevoEmpleadoActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in, android.R.anim.fade_out);
            }
        });

        // Botón para buscar por años de experiencia
        btnBuscarExperiencia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InicioActivity.this, BuscarExperienciaActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.fade_in, android.R.anim.fade_out);
            }
        });
    }
}
