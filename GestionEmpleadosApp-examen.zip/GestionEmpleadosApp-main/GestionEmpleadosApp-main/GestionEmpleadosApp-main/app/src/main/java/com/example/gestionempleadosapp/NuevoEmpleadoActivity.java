package com.example.gestionempleadosapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class NuevoEmpleadoActivity extends AppCompatActivity {
    private EditText editTextNombre;
    private EditText editTextId;
    private EditText editTextDepartamento;
    private EditText editTextSalario;
    private EditText editTextAniosExperiencia;
    private EditText editTextBonificacion;
    private EditText editTextNumber;
    private EditText editTextHorasSemanales;
    private EditText editTextTarifaPorHora;
    private EditText editTextDuracionContrato;
    private EditText editTextTarifaProyecto;
    private RadioGroup radioGroupTipoEmpleado;
    private LinearLayout layoutMedioTiempo;
    private LinearLayout layoutContratista;
    private Button buttonGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_empleado);

        // Inicializar vistas
        editTextNombre = findViewById(R.id.editTextNombre);
        editTextId = findViewById(R.id.editTextId);
        editTextDepartamento = findViewById(R.id.editTextDepartamento);
        editTextSalario = findViewById(R.id.editTextSalario);
        editTextAniosExperiencia = findViewById(R.id.editTextAniosExperiencia);
        editTextBonificacion = findViewById(R.id.editTextBonificacion);
        editTextNumber = findViewById(R.id.editTextNumber);
        editTextHorasSemanales = findViewById(R.id.editTextHorasSemanales);
        editTextTarifaPorHora = findViewById(R.id.editTextTarifaPorHora);
        editTextDuracionContrato = findViewById(R.id.editTextDuracionContrato);
        editTextTarifaProyecto = findViewById(R.id.editTextTarifaProyecto);
        radioGroupTipoEmpleado = findViewById(R.id.radioGroupTipoEmpleado);
        layoutMedioTiempo = findViewById(R.id.layoutMedioTiempo);
        layoutContratista = findViewById(R.id.layoutContratista);
        buttonGuardar = findViewById(R.id.buttonGuardar);

        // Configurar listener para mostrar/ocultar campos específicos
        radioGroupTipoEmpleado.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                layoutMedioTiempo.setVisibility(View.GONE);
                layoutContratista.setVisibility(View.GONE);
                
                if (checkedId == R.id.radioMedioTiempo) {
                    layoutMedioTiempo.setVisibility(View.VISIBLE);
                } else if (checkedId == R.id.radioContratista) {
                    layoutContratista.setVisibility(View.VISIBLE);
                }
            }
        });

        buttonGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarEmpleado();
            }
        });
    }

    private void guardarEmpleado() {
        try {
            String nombre = editTextNombre.getText().toString();
            String id = editTextId.getText().toString();
            String departamento = editTextDepartamento.getText().toString();
            double salarioBase = Double.parseDouble(editTextSalario.getText().toString());
            int aniosExperiencia = Integer.parseInt(editTextAniosExperiencia.getText().toString());
            double bonificacion = Double.parseDouble(editTextBonificacion.getText().toString());
            int number = Integer.parseInt(editTextNumber.getText().toString());
            
            Empleado nuevoEmpleado = null;
            int tipoEmpleado = radioGroupTipoEmpleado.getCheckedRadioButtonId();
            
            if (tipoEmpleado == R.id.radioTiempoCompleto) {
                nuevoEmpleado = new EmpleadoTiempoCompleto(nombre, id, departamento, salarioBase, aniosExperiencia, bonificacion, number);
            } else if (tipoEmpleado == R.id.radioMedioTiempo) {
                int horasSemanales = Integer.parseInt(editTextHorasSemanales.getText().toString());
                double tarifaPorHora = Double.parseDouble(editTextTarifaPorHora.getText().toString());
                nuevoEmpleado = new EmpleadoMedioTiempo(nombre, id, departamento, salarioBase, aniosExperiencia, horasSemanales, tarifaPorHora, number);
            } else if (tipoEmpleado == R.id.radioContratista) {
                int duracionContrato = Integer.parseInt(editTextDuracionContrato.getText().toString());
                double tarifaProyecto = Double.parseDouble(editTextTarifaProyecto.getText().toString());
                nuevoEmpleado = new Contratista(nombre, id, departamento, salarioBase, aniosExperiencia, duracionContrato, tarifaProyecto, number);
            }

            if (nuevoEmpleado != null) {
                // Agregar el empleado a la lista global
                GestorEmpleados.agregarEmpleado(nuevoEmpleado);
                Toast.makeText(this, "Empleado guardado exitosamente", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Por favor seleccione un tipo de empleado", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Por favor ingrese valores numéricos válidos", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error al guardar el empleado: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
} 