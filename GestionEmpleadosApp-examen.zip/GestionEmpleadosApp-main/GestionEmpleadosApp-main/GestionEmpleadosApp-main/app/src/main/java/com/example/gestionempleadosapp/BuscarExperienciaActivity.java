package com.example.gestionempleadosapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class BuscarExperienciaActivity extends AppCompatActivity {
    private EditText editTextAniosExperiencia;
    private Button buttonBuscar;
    private ListView listViewResultados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buscar_experiencia);

        editTextAniosExperiencia = findViewById(R.id.editTextAniosExperiencia);
        buttonBuscar = findViewById(R.id.buttonBuscar);
        listViewResultados = findViewById(R.id.listViewResultados);

        buttonBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buscarPorExperiencia();
            }
        });
    }

    private void buscarPorExperiencia() {
        try {
            int aniosBuscados = Integer.parseInt(editTextAniosExperiencia.getText().toString());
            ArrayList<Empleado> resultados = new ArrayList<>();
            ArrayList<Empleado> empleados = GestorEmpleados.getEmpleados();

            for (Empleado emp : empleados) {
                if (emp.getAniosExperiencia() == aniosBuscados) {
                    resultados.add(emp);
                }
            }

            if (resultados.isEmpty()) {
                Toast.makeText(this, "No se encontraron empleados con " + aniosBuscados + " años de experiencia", Toast.LENGTH_SHORT).show();
            } else {
                EmpleadoAdapter adapter = new EmpleadoAdapter(this, resultados);
                listViewResultados.setAdapter(adapter);
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Por favor ingrese un número válido", Toast.LENGTH_SHORT).show();
        }
    }
} 