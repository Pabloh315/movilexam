package com.example.gestionempleadosapp;

public class EmpleadoMedioTiempo extends Empleado {
    private int horasSemanales;
    private double tarifaPorHora;

    public EmpleadoMedioTiempo(String nombre, String id, String departamento, double salarioBase, int aniosExperiencia, int horasSemanales, double tarifaPorHora, int number) {
        super(nombre, id, departamento, salarioBase, aniosExperiencia, number);
        this.horasSemanales = horasSemanales;
        this.tarifaPorHora = tarifaPorHora;
    }

    @Override
    public double calcularSalario() {
        return horasSemanales * tarifaPorHora * 4; // Sueldo mensual estimado
    }

    @Override
    public String obtenerInformacion() {
        return "Empleado Medio Tiempo:\n"
                + "Nombre: " + getNombreCompleto() + "\n"
                + "ID: " + getId() + "\n"
                + "Departamento: " + getDepartamento() + "\n"
                + "Años de experiencia: " + getAniosExperiencia() + "\n"
                + "Horas semanales: " + horasSemanales + "\n"
                + "Tarifa por hora: " + tarifaPorHora + "\n"
                + "Salario: " + calcularSalario() + "\n"
                + "Número: " + number;
    }
}
