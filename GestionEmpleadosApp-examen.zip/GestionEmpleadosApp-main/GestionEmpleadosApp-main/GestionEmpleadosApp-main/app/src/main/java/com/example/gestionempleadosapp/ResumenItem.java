package com.example.gestionempleadosapp;

public class ResumenItem {
    private String tipo;
    private int total;

    public ResumenItem(String tipo, int total) {
        this.tipo = tipo;
        this.total = total;
    }

    public String getTipo() {
        return tipo;
    }

    public int getTotal() {
        return total;
    }
}
