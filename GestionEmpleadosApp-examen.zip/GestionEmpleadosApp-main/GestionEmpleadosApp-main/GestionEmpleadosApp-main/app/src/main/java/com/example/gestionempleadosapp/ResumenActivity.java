package com.example.gestionempleadosapp;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import java.util.ArrayList;

public class ResumenActivity extends AppCompatActivity {
    private TextView textViewResumen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumen);

        // Toolbar elegante
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        textViewResumen = findViewById(R.id.textViewResumen);
        mostrarResumen();
    }

    private void mostrarResumen() {
        ArrayList<Empleado> empleados = GestorEmpleados.getEmpleados();
        int tiempoCompleto = 0;
        int medioTiempo = 0;
        int contratistas = 0;
        double totalSalarios = 0;

        for (Empleado emp : empleados) {
            if (emp instanceof EmpleadoTiempoCompleto) {
                tiempoCompleto++;
            } else if (emp instanceof EmpleadoMedioTiempo) {
                medioTiempo++;
            } else if (emp instanceof Contratista) {
                contratistas++;
            }
            totalSalarios += emp.calcularSalario();
        }

        StringBuilder resumen = new StringBuilder();
        resumen.append("Resumen de Empleados\n\n");
        resumen.append("Empleados a Tiempo Completo: ").append(tiempoCompleto).append("\n");
        resumen.append("Empleados a Medio Tiempo: ").append(medioTiempo).append("\n");
        resumen.append("Contratistas: ").append(contratistas).append("\n");
        resumen.append("Total de Empleados: ").append(empleados.size()).append("\n");
        resumen.append("Total de Salarios: $").append(String.format("%.2f", totalSalarios)).append("\n");

        textViewResumen.setText(resumen.toString());
    }

    @Override
    protected void onResume() {
        super.onResume();
        mostrarResumen(); // Actualizar el resumen cuando se vuelve a la actividad
    }
}
