package com.example.gestionempleadosapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ResumenAdapter extends ArrayAdapter<ResumenItem> {
    public ResumenAdapter(Context context, List<ResumenItem> resumen) {
        super(context, 0, resumen);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ResumenItem item = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_resumen, parent, false);
        }

        TextView tipo = convertView.findViewById(R.id.tipoResumen);
        TextView total = convertView.findViewById(R.id.totalResumen);

        tipo.setText(item.getTipo());
        total.setText("Total: " + item.getTotal());

        return convertView;
    }
}
