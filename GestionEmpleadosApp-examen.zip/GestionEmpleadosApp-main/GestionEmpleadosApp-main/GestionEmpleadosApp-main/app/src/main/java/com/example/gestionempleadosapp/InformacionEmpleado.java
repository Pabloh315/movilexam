package com.example.gestionempleadosapp;

public interface InformacionEmpleado {
    double calcularSalario();
    String obtenerInformacion();
}
